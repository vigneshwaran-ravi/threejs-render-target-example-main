# threejs-render-target-example
threejs-render-target-example

Try the [Stackblitz](https://stackblitz.com/github/tamani-coding/threejs-render-target-example) 

![Screenshot](https://github.com/tamani-coding/threejs-render-target-example/blob/main/screenshot01.png?raw=true)

Use `npm install` and then `npm run start`.
